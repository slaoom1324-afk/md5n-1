package dev.md5n.module.modules;

import dev.md5n.Md5n;
import dev.md5n.module.Category;
import dev.md5n.module.Module;
import dev.md5n.setting.BoolSetting;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.Locale;

public class Hud extends Module {
    private static final int WHITE = 0xFFFFFFFF;

    private final BoolSetting watermark = bool("Watermark", true, "Show the client name and version");
    private final BoolSetting fps = bool("FPS", true, "Show your frame rate");
    private final BoolSetting coords = bool("Coordinates", true, "Show your XYZ position");
    private final BoolSetting moduleList = bool("Module List", true, "List enabled modules on the right");

    public Hud() {
        super("HUD", Category.VISUAL, "Watermark, FPS, coordinates and module list");
    }

    @Override
    public void onHudRender(DrawContext ctx) {
        if (mc.player == null) return;
        TextRenderer tr = mc.textRenderer;

        ThemeSettings theme = Md5n.modules.get(ThemeSettings.class);
        int accent = theme == null ? 0xFF55FFFF : theme.accent();

        int ly = 4;
        if (watermark.get()) {
            ctx.drawTextWithShadow(tr, Md5n.NAME + " " + Md5n.VERSION, 4, ly, accent);
            ly += 12;
        }
        if (fps.get()) {
            ctx.drawTextWithShadow(tr, mc.getCurrentFps() + " FPS", 4, ly, WHITE);
            ly += 12;
        }
        if (coords.get()) {
            ctx.drawTextWithShadow(tr, String.format(Locale.ROOT, "XYZ %.1f %.1f %.1f",
                    mc.player.getX(), mc.player.getY(), mc.player.getZ()), 4, ly, WHITE);
            ly += 12;
        }

        ElytraTarget elytraTarget = Md5n.modules.get(ElytraTarget.class);
        String lock = elytraTarget == null ? null : elytraTarget.hudText();
        if (lock != null) {
            ctx.drawTextWithShadow(tr, "Locked: " + lock, 4, ly, accent);
        }

        if (moduleList.get()) {
            int width = ctx.getScaledWindowWidth();
            int y = 4;
            for (Module m : Md5n.modules.all()) {
                if (m == this || !m.isEnabled()) continue;
                ctx.drawTextWithShadow(tr, m.name, width - tr.getWidth(m.name) - 4, y, accent);
                y += 11;
            }
        }
    }
}
