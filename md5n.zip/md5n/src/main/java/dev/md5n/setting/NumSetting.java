package dev.md5n.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.Locale;

public class NumSetting extends Setting {
    public final double min, max, step;
    private double value;

    public NumSetting(String name, double def, double min, double max, double step, String description) {
        super(name, description);
        this.min = min;
        this.max = max;
        this.step = step;
        this.value = def;
    }

    public double get() { return value; }

    public int getInt() { return (int) Math.round(value); }

    public float getFloat() { return (float) value; }

    public void set(double v) {
        double c = Math.max(min, Math.min(max, v));
        if (step > 0) c = min + Math.round((c - min) / step) * step;
        value = Math.max(min, Math.min(max, c));
    }

    public double fraction() { return (value - min) / (max - min); }

    public String display() {
        return step >= 1 ? String.valueOf(Math.round(value)) : String.format(Locale.ROOT, "%.2f", value);
    }

    @Override
    public JsonElement toJson() { return new JsonPrimitive(value); }

    @Override
    public void fromJson(JsonElement element) { set(element.getAsDouble()); }
}
