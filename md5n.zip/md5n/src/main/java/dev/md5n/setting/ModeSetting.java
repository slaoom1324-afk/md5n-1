package dev.md5n.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class ModeSetting extends Setting {
    public final String[] modes;
    private int index;

    public ModeSetting(String name, String def, String description, String... modes) {
        super(name, description);
        this.modes = modes;
        for (int i = 0; i < modes.length; i++) {
            if (modes[i].equals(def)) index = i;
        }
    }

    public String get() { return modes[index]; }

    public boolean is(String mode) { return modes[index].equals(mode); }

    public void next() { index = (index + 1) % modes.length; }

    public void prev() { index = (index - 1 + modes.length) % modes.length; }

    @Override
    public boolean keyable() { return true; }

    @Override
    public void onKey() { next(); }

    @Override
    public JsonElement toJson() { return new JsonPrimitive(get()); }

    @Override
    public void fromJson(JsonElement element) {
        String v = element.getAsString();
        for (int i = 0; i < modes.length; i++) {
            if (modes[i].equals(v)) { index = i; return; }
        }
    }
}
